INSERT INTO `config` (`config_name`, `config_value`, `config_group`, `config_type`)
    VALUES ('budget_info_display', 'false', 'budgeting', 'checkbox');