
INSERT INTO `config` (`config_name` , `config_value` , `config_group` , `config_type`)
    VALUES ('ldap_complete_string', '', 'ldap', 'text');