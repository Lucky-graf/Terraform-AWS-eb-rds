

ALTER TABLE  `custom_fields_struct` CHANGE  `field_id`  `field_id` INT( 11 ) NOT NULL AUTO_INCREMENT;