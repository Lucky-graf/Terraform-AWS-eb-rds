ALTER TABLE `projects` CHANGE `project_id` `project_id`
    INT(10) NOT NULL AUTO_INCREMENT;
