
-- Some missing sysvals

INSERT INTO `sysvals` (`sysval_key_id`, `sysval_title`, `sysval_value`, `sysval_value_id`)
VALUES
(4, 'ContactMethods', 'Email: Primary', 'email_primary'),
(4, 'ContactMethods', 'Phone: Primary', 'phone_primary');