#20070513
#removed jpLocale variable - use user locale instead.
DELETE FROM `config` WHERE config_name = 'jpLocale';