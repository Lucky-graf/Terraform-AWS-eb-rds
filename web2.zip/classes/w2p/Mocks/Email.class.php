<?php

/**
 * @package     web2project\mocks
 * @author      D. Keith Casey, Jr. <caseydk@users.sourceforge.net>
 */

class w2p_Mocks_Email extends w2p_Utilities_Mail {
    
    public function Send() {
        return;
    }
}