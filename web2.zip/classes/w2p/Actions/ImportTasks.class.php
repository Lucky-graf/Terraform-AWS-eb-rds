<?php

/**
 * Class w2p_Actions_ImportTasks
 *
 * @deprecated
 */
class w2p_Actions_ImportTasks extends w2p_Actions_BulkTasks
{

}