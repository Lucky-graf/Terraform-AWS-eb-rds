
| Name | Company | Amount | Date |
|---------|:-----:|:-----:|:-----:|
|Katia Emidio da Silva | http://www.cpaa.embrapa.br | $50 | 01 August 2014 |
|Katia Emidio da Silva | http://www.cpaa.embrapa.br | $50 | 02 July 2014 |
|Marc Leger | http://www.voxinteractif.com | $100 | 19 February 2014 |