<?php
$locale_char_set = 'utf-8'; // must be lower-case! because w2p doesn't check case-insensitively against this!
// 0 = sunday, 1 = monday
define('LOCALE_FIRST_DAY', 0);
define('LOCALE_TIME_FORMAT', '%I:%M %p');