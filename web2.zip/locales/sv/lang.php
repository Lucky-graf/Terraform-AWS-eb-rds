<?php 
// Language list for supported locales.
// This is used in the 2.0 version of dotproject to correctly identify Windows language
// support.  See the English version for details of its format.
$dir = basename(dirname(__FILE__));

$LANGUAGES['sv_SE'] = array( $dir, 'Swedish', 'Svenska', 'sv_SE', 'utf-8');
