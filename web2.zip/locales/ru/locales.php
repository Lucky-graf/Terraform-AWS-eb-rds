<?php
$locale_char_set = 'utf-8';
// 0 = sunday, 1 = monday
define('LOCALE_FIRST_DAY', 1);
define('LOCALE_TIME_FORMAT', '%H:%M');
define('LOCALE_DATE_FORMAT', '%d.%m.%y');