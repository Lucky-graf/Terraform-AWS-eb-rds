<?php
if (!defined('W2P_BASE_DIR')) {
	die('You should not access this file directly.');
}

/**
 * @deprecated since version 3.0
 */