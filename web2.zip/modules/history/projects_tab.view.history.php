<?php
if (!defined('W2P_BASE_DIR')) {
	die('You should not access this file directly');
}

$filter_param = 'projects';
require W2P_BASE_DIR . '/modules/history/index_table.php';