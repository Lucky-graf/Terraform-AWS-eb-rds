<?php
// Set the version components separately.
$w2p_version_major = 3;
$w2p_version_minor = 4;
$w2p_version_patch = 0; // Can be set to null if not used
$w2p_version_prepatch = null; // Set to null if a release version.
